#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(int argc, string argv[])
{
    //declares the command line argument as a string called "k" this will be the key word
    string k = argv[1];
    // checks to make sure that there is only one key word
    if (argc != 2)
    {
        printf("usage: ./vigenere keyword\n");   
        return 1;
    }
    int strlenk = strlen(k);
    // checks to make sure that the key word is a string made up of ONLY alphabetical characters
    for (int i = 0; i < strlenk; i++)
    {
        if (!isalpha(k[i]))
        {
            printf("usage: ./vigenere keyword\n");  
            return 1;
        }    
    }
    // converts letters in the key word from ASCII to a 0 through 25 number system 
    for (int i = 0; i < strlenk; i++)        
        if (isupper(k[i]))
        {
            k[i] = k[i] - 'A';
        }
        else if (islower(k[i]))
        {
            k[i] = k[i] - 'a';
        }
    // gets the message that will be encrypted in the cipher from the user
    string p = get_string("plaintext: ");                                                                    
    int strlenp = strlen(p);
    int j = 0;
    printf("ciphertext: ");
    // this for loop performs cipher by iterating over each character of the plaintext and applying each character of the key word
    for (int i = 0; i < strlenp; i++)        
        if (isalpha(p[i]))                
        {
            //j ensures that the key word will start back over at the first char of the string after reaching the null char
            j = (j % strlenk);
            if (isupper(p[i]))
            {
                p[i] = p[i] - 'A';
                printf("%c", (p[i] + k[j]) % 26 + 'A');
            }
            else if (islower(p[i]))
            {
                p[i] = p[i] - 'a';
                printf("%c", (p[i] + k[j]) % 26 + 'a');
            }        
            j++;
        }
                       
//prints out spaces and symbols unchanged
        else if (isspace(p[i]) || ispunct(p[i]))
        {
            printf("%c", p[i]);
        }
    j++;
    printf("\n");
    return 0;
}


    

